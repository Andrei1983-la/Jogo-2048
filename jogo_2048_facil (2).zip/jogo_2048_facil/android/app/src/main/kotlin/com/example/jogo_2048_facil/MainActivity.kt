package com.example.jogo_2048_facil

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
