import 'package:flutter/material.dart';
import 'package:jogo_2048_facil/main.dart'; //

class DifficultySelectionScreen extends StatelessWidget {
  const DifficultySelectionScreen({super.key});

  void _startGame(BuildContext context, int boardSize, int winningTile) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder:
            (context) =>
                GameScreen(boardSize: boardSize, winningTile: winningTile),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('2048 - Selecione a Dificuldade'),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Escolha o Nível de Dificuldade:',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 40),
            ElevatedButton(
              onPressed: () => _startGame(context, 4, 1024), // Nível Fácil
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(200, 60),

                padding: const EdgeInsets.symmetric(
                  horizontal: 30,
                  vertical: 15,
                ),
                textStyle: const TextStyle(fontSize: 20),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                backgroundColor: Colors.blueGrey[700],
                //
                foregroundColor: Colors.white,
              ),
              child: const Text('Fácil (4x4 - 1024)'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => _startGame(context, 5, 2048), // Nível Médio
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(200, 60),
                padding: const EdgeInsets.symmetric(
                  horizontal: 30,
                  vertical: 15,
                ),
                textStyle: const TextStyle(fontSize: 20),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                backgroundColor: Colors.blueGrey[800],
                foregroundColor: Colors.white,
              ),
              child: const Text('Médio (5x5 - 2048)'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => _startGame(context, 6, 4096), // Nível Difícil
              style: ElevatedButton.styleFrom(
                minimumSize: const Size(200, 60),
                padding: const EdgeInsets.symmetric(
                  horizontal: 30,
                  vertical: 15,
                ),
                textStyle: const TextStyle(fontSize: 20),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                backgroundColor: Colors.blueGrey[900],
                foregroundColor: Colors.white,
              ),
              child: const Text('Difícil (6x6 - 4096)'),
            ),
          ],
        ),
      ),
    );
  }
}
