import 'package:flutter/material.dart';
import 'dart:math';
import 'package:jogo_2048_facil/tile_widget.dart';
import 'package:jogo_2048_facil/difficulty_selection_screen.dart'; // Importa a nova tela

enum Direction { up, down, left, right }

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '2048 Game',
      theme: ThemeData(primarySwatch: Colors.blueGrey, useMaterial3: true),
      home: const DifficultySelectionScreen(),
    );
  }
}

class GameScreen extends StatefulWidget {
  final int boardSize;
  final int winningTile;

  const GameScreen({
    super.key,
    required this.boardSize,
    required this.winningTile,
  });

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  late int currentBoardSize;
  late int currentWinningTile;
  List<List<int>> board = [];

  Offset? _startDrag;
  Offset? _endDrag;

  @override
  void initState() {
    super.initState();
    currentBoardSize = widget.boardSize;
    currentWinningTile = widget.winningTile;
    _initializeBoard();
  }

  @override
  void didUpdateWidget(covariant GameScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.boardSize != oldWidget.boardSize ||
        widget.winningTile != oldWidget.winningTile) {
      currentBoardSize = widget.boardSize;
      currentWinningTile = widget.winningTile;
      _initializeBoard();
    }
  }

  void _initializeBoard() {
    board = List.generate(
      currentBoardSize,
      (_) => List.filled(currentBoardSize, 0),
    );
    _addNewTile();
    _addNewTile();
    _printBoard();
  }

  void _addNewTile() {
    List<Offset> emptyCells = [];
    for (int i = 0; i < currentBoardSize; i++) {
      for (int j = 0; j < currentBoardSize; j++) {
        if (board[i][j] == 0) {
          emptyCells.add(Offset(i.toDouble(), j.toDouble()));
        }
      }
    }

    if (emptyCells.isNotEmpty) {
      final random = Random();
      final cell = emptyCells[random.nextInt(emptyCells.length)];
      final value = random.nextDouble() < 0.9 ? 2 : 4;

      setState(() {
        board[cell.dx.toInt()][cell.dy.toInt()] = value;
      });
    } else {
      print(
        'DEBUG: Tabuleiro cheio, não é possível adicionar nova peça. (Game Over em breve)',
      );
    }
  }

  void _printBoard() {
    for (int i = 0; i < currentBoardSize; i++) {
      print(board[i]);
    }
    print('---');
  }

  void _handleSwipe() {
    print('DEBUG (_handleSwipe): Função _handleSwipe foi chamada.');
    if (_startDrag == null || _endDrag == null) {
      print('DEBUG (_handleSwipe): startDrag ou endDrag é nulo.');
      return;
    }

    double dx = _endDrag!.dx - _startDrag!.dx;
    double dy = _endDrag!.dy - _startDrag!.dy;

    print('DEBUG (_handleSwipe): dx: $dx, dy: $dy');
    print('DEBUG (_handleSwipe): dx.abs(): ${dx.abs()}, dy.abs(): ${dy.abs()}');

    if (dx.abs() > 5 || dy.abs() > 5) {
      print(
        'DEBUG (_handleSwipe): Movimento significativo detectado (limite 5).',
      );
      if (dx.abs() > dy.abs()) {
        if (dx > 0) {
          _moveTiles(Direction.right);
        } else {
          _moveTiles(Direction.left);
        }
      } else {
        if (dy > 0) {
          _moveTiles(Direction.down);
        } else {
          _moveTiles(Direction.up);
        }
      }
    } else {
      print(
        'DEBUG (_handleSwipe): Movimento muito pequeno. Não atinge o limite de 5.',
      );
    }

    _startDrag = null;
    _endDrag = null;
  }

  List<int> _processLine(List<int> line, bool reverse) {
    List<int> temp = line.where((tile) => tile != 0).toList();
    List<int> processed = [];

    for (int i = 0; i < temp.length; i++) {
      int currentValue = temp[i];
      if (i + 1 < temp.length && temp[i + 1] == currentValue) {
        processed.add(currentValue * 2);
        i++;
      } else {
        processed.add(currentValue);
      }
    }

    while (processed.length < currentBoardSize) {
      processed.add(0);
    }

    if (reverse) {
      return processed.reversed.toList();
    }
    return processed;
  }

  void _moveTiles(Direction direction) {
    print('DEBUG: _moveTiles chamada para direção: $direction');
    bool moved = false;
    List<List<int>> newBoard = List.generate(
      currentBoardSize,
      (_) => List.filled(currentBoardSize, 0),
    );

    List<List<int>> oldBoard = List.generate(
      currentBoardSize,
      (row) => List.generate(currentBoardSize, (col) => board[row][col]),
    );

    if (direction == Direction.up) {
      print('DEBUG: Processando movimento para CIMA');
      for (int col = 0; col < currentBoardSize; col++) {
        List<int> currentColumn = [];
        for (int row = 0; row < currentBoardSize; row++) {
          currentColumn.add(board[row][col]);
        }
        print('DEBUG (CIMA): Coluna $col original: $currentColumn');
        List<int> processedColumn = _processLine(currentColumn, false);
        print('DEBUG (CIMA): Coluna $col processada: $processedColumn');

        for (int row = 0; row < currentBoardSize; row++) {
          newBoard[row][col] = processedColumn[row];
        }
      }
    } else if (direction == Direction.down) {
      print('DEBUG: Processando movimento para BAIXO');
      for (int col = 0; col < currentBoardSize; col++) {
        //
        List<int> currentColumn = [];
        for (int row = 0; row < currentBoardSize; row++) {
          //
          currentColumn.add(board[row][col]);
        }
        print('DEBUG (BAIXO): Coluna $col original: $currentColumn');
        List<int> processedColumn = _processLine(currentColumn, true);
        print(
          'DEBUG (BAIXO): Coluna $col processada (invertida): $processedColumn',
        );

        for (int row = 0; row < currentBoardSize; row++) {
          newBoard[row][col] = processedColumn[row];
        }
      }
    } else if (direction == Direction.left) {
      print('DEBUG: Processando movimento para ESQUERDA');
      for (int row = 0; row < currentBoardSize; row++) {
        List<int> currentRow = [];
        for (int col = 0; col < currentBoardSize; col++) {
          currentRow.add(board[row][col]);
        }
        print('DEBUG (ESQUERDA): Linha $row original: $currentRow');
        List<int> processedRow = _processLine(currentRow, false);
        print('DEBUG (ESQUERDA): Linha $row processada: $processedRow');

        for (int col = 0; col < currentBoardSize; col++) {
          newBoard[row][col] = processedRow[col];
        }
      }
    } else if (direction == Direction.right) {
      print('DEBUG: Processando movimento para DIREITA');
      for (int row = 0; row < currentBoardSize; row++) {
        List<int> currentRow = [];
        for (int col = 0; col < currentBoardSize; col++) {
          currentRow.add(board[row][col]);
        }
        print('DEBUG (DIREITA): Linha $row original: $currentRow');
        List<int> processedRow = _processLine(currentRow, true);
        print(
          'DEBUG (DIREITA): Linha $row processada (invertida): $processedRow',
        );

        for (int col = 0; col < currentBoardSize; col++) {
          newBoard[row][col] = processedRow[col];
        }
      }
    }

    moved = false;
    for (int r = 0; r < currentBoardSize; r++) {
      for (int c = 0; c < currentBoardSize; c++) {
        if (oldBoard[r][c] != newBoard[r][c]) {
          moved = true;
          break;
        }
      }
      if (moved) break;
    }

    print('DEBUG: Tabuleiro antigo (oldBoard):');
    _printBoardMatrix(oldBoard);
    print('DEBUG: Novo tabuleiro calculado (newBoard):');
    _printBoardMatrix(newBoard);
    print('DEBUG: Moved flag: $moved');

    if (moved) {
      setState(() {
        board = newBoard;
      });
      print('DEBUG: Houve movimento, adicionando nova peça e atualizando UI.');
      _addNewTile();
      _printBoard();
    } else {
      print('DEBUG: Nenhum movimento detectado, não atualizando UI.');
      _printBoard();
    }
  }

  void _printBoardMatrix(List<List<int>> matrix) {
    for (int i = 0; i < currentBoardSize; i++) {
      print(matrix[i]);
    }
    print('---');
  }

  @override
  Widget build(BuildContext context) {
    final double boardDimension = MediaQuery.of(context).size.width * 0.9;

    return Scaffold(
      appBar: AppBar(
        title: Text('2048 - Nível ${widget.boardSize}x${widget.boardSize}'),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 20),
            GestureDetector(
              onPanStart: (details) {
                _startDrag = details.globalPosition;
                print('DEBUG: onPanStart disparado.');
              },
              onPanEnd: (details) {
                _endDrag = details.globalPosition;
                print('DEBUG: onPanEnd disparado.');
                _handleSwipe();
              },
              child: Container(
                width: boardDimension,
                height: boardDimension,
                margin: const EdgeInsets.all(8.0),
                decoration: BoxDecoration(
                  color: Colors.grey[400],
                  borderRadius: BorderRadius.circular(8.0),
                ),
                child: GridView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: currentBoardSize,
                    crossAxisSpacing: 8.0,
                    mainAxisSpacing: 8.0,
                  ),
                  itemCount: currentBoardSize * currentBoardSize,
                  itemBuilder: (context, index) {
                    int row = index ~/ currentBoardSize;
                    int col = index % currentBoardSize;
                    int tileValue = board[row][col];
                    return TileWidget(value: tileValue);
                  },
                ),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _initializeBoard,
              child: const Text('Reiniciar Jogo'),
            ),
          ],
        ),
      ),
    );
  }
}
